# -*- coding: utf-8 -*-
"""에임 따라가기: 움직이는 원 안에 마우스를 올려 두고, 게이지를 목표 시간만큼 채워요"""
import math
import pygame

from .. import config
from ..ui import draw_round, aa_circle
from .base import Mission

AREA = pygame.Rect(120, 150, 1040, 500)


class Aim(Mission):
    key = "aim"
    name = "에임 따라가기"
    blurb = "움직이는 목표를 따라가요"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.radius = self.p["radius"]
        self.speed = self.p["speed"]
        self.decay = self.p["decay"]
        self.target = self.p["target"]
        self.pos = pygame.Vector2(AREA.center)
        self.vel = pygame.Vector2(1, 0).rotate(self.rng.uniform(0, 360)) * self.speed
        self.turn_in = self.rng.uniform(0.8, 1.8)
        self.gauge = 0.0
        self.inside_t = 0.0
        self.total_t = 0.0
        self.inside = False

    def rules(self):
        lines = [
            "움직이는 원 안에 마우스 커서를 올려 두세요.",
            "원 안에 있는 동안 게이지가 차요. 모두 합쳐 %.0f초를 채우면 클리어예요." % self.target,
        ]
        if self.decay > 0:
            lines.append("커서가 원 밖으로 나가면 게이지가 초당 %.1f초씩 줄어요." % self.decay)
        else:
            lines.append("원 밖으로 나가도 게이지는 줄지 않아요.")
        return lines

    def controls(self):
        return "마우스 이동"

    def update(self, dt):
        super().update(dt)
        if self.status != "playing":
            return
        # 원 이동: 가끔 방향을 바꾸고, 벽에 부딪히면 튕겨요
        self.turn_in -= dt
        if self.turn_in <= 0:
            self.vel = self.vel.rotate(self.rng.uniform(-80, 80))
            self.turn_in = self.rng.uniform(0.8, 1.8)
        self.pos += self.vel * dt
        r = self.radius
        if self.pos.x < AREA.left + r:
            self.pos.x, self.vel.x = AREA.left + r, abs(self.vel.x)
        elif self.pos.x > AREA.right - r:
            self.pos.x, self.vel.x = AREA.right - r, -abs(self.vel.x)
        if self.pos.y < AREA.top + r:
            self.pos.y, self.vel.y = AREA.top + r, abs(self.vel.y)
        elif self.pos.y > AREA.bottom - r:
            self.pos.y, self.vel.y = AREA.bottom - r, -abs(self.vel.y)
        # 게이지
        mouse = pygame.Vector2(pygame.mouse.get_pos())
        self.inside = mouse.distance_to(self.pos) <= r
        self.total_t += dt
        if self.inside:
            self.gauge += dt
            self.inside_t += dt
            if self.gauge >= self.target:
                self.gauge = self.target
                self.sfx("correct")
                self.win()
        else:
            self.gauge = max(0.0, self.gauge - self.decay * dt)

    def accuracy(self):
        return self.inside_t / self.total_t if self.total_t > 0 else None

    def stats(self):
        return ["원 안에 있었던 시간 %.1f초 / 전체 %.1f초" % (self.inside_t, self.total_t)]

    def draw(self, surf):
        self.text(surf, "게이지  %.1f / %.0f초" % (self.gauge, self.target), 34, self.fg, (640, 112))
        draw_round(surf, config.PANEL, AREA.inflate(20, 20), 30)
        aa_circle(surf, config.YELLOW if self.inside else config.ICE, self.pos, self.radius)
        bar = pygame.Rect(0, 0, 640, 24)
        bar.center = (640, 686)
        draw_round(surf, (0, 0, 0), bar, 12)
        w = int(bar.w * self.gauge / self.target)
        if w > 0:
            draw_round(surf, config.YELLOW, (bar.x, bar.y, max(w, 24), bar.h), 12)
