# Safe Rush: 금고를 열어라!

제한 시간 안에 **랜덤 미니게임 5개**를 모두 클리어해서 금고를 여는 Python(pygame) 게임입니다.
미니게임을 클리어할 때마다 남은 시간이 늘어납니다. (기본 +10초 / 기억력·암산은 문제마다 +5초, 클리어 +5초) 기록은 SQLite 랭킹에 저장됩니다.

## 실행 방법

### 1) 소스로 실행 (Python 3.10 이상)
```
pip install -r requirements.txt
python main.py
```

### 2) exe 만들기 (Windows)
`build.bat` 을 더블클릭하면 `dist\safe_rush\safe_rush.exe` 가 만들어집니다.
(`dist\safe_rush` 폴더 전체를 zip 으로 묶어 배포하세요.)

랭킹과 설정은 `%APPDATA%\SafeRush\` 에 저장되고, 오류가 나면 같은 폴더의 `error_log.txt` 에 기록됩니다.

## 게임 방법
| 난이도 | 시작 시간 | 특징 |
|---|---|---|
| 쉬움 | 무제한 | 이니셜 입력 없음, 랭킹 기록 없음 |
| 보통 | 60초 | 클리어마다 +10초 |
| 챌린지 | 45초 | 더 어려운 설정, 보스 BGM |

- 미니게임 시작 전 **설명 창**에서는 시간이 멈춥니다.
- 설명 창에서 `0` 키를 1초간 누르면 다른 미니게임으로 **스킵** (한 판에 2회, 남은 시간 -5초 / 기록 +5초).
- `ESC` : 일시정지 메뉴, `F11` : 전체 화면.

## 미니게임
다른 색상 찾기 · 반응속도 테스트 · 타자 미션(애국가) · 짝 맞추기 · 숫자 순서 터치 · 기억력 게임 · 암산 챌린지 · 에임 따라가기 · 퍼펙트 클리어(테트리스, 준비 중)

## 폴더 구조
```
safe_rush/
├── main.py              실행 시작 파일
├── build.bat            exe 만들기
├── requirements.txt
├── assets/              bgm · fonts · data
└── game/
    ├── app.py config.py db.py audio.py sfx.py art.py ui.py ...
    ├── missions/        미니게임 (Mission 클래스를 상속)
    └── scenes/          타이틀 · 설정 · 난이도 · 플레이 · 결과 · 랭킹 ...
```
밸런스(제한 시간, 난이도 수치)는 `game/config.py` 만 고치면 됩니다.

## 사용한 기술
Python 3 · pygame · SQLite · PyInstaller · AI(Claude)와 함께 제작

## 출처 / 라이선스
- 음원: © Juhani Junkala, *Chiptune Adventures* (CC0)
- 글꼴: Noto Sans CJK KR (SIL Open Font License, `assets/fonts/LICENSE-NotoSansCJK.txt`)
- 효과음: 코드로 직접 합성
- 제작: 안기현
